// Copyright (2017) Baidu Inc. All rights reserveed.
/**
 * File: duerapp_dcs.c
 * Auth:       
 * Desc: About DCS 3.0
 */

#ifndef BAIDU_DUER_DUERAPP_DCS_H
#define BAIDU_DUER_DUERAPP_DCS_H

#include "lightduer_dcs.h"

void duer_dcs_init(void);

#endif // BAIDU_DUER_DUERAPP_DCS_H