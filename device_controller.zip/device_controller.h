#ifndef BAIDU_IOT_OPENAPI_CORE_STATIC_RESOURCES_DEVICE_CONTROLLER_H
#define BAIDU_IOT_OPENAPI_CORE_STATIC_RESOURCES_DEVICE_CONTROLLER_H

#ifdef __cplusplus
extern "C" {
#endif

extern void device_controller_init(void);

#ifdef __cplusplus
}
#endif

#endif/*BAIDU_IOT_OPENAPI_CORE_STATIC_RESOURCES_DEVICE_CONTROLLER_H*/