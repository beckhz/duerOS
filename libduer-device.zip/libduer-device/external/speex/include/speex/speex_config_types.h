#ifndef _SPEEX_CONFIG_TYPES_H
#define _SPEEX_CONFIG_TYPES_H

typedef signed short spx_int16_t;
typedef unsigned short spx_uint16_t;
typedef signed int spx_int32_t;
typedef unsigned int spx_uint32_t;

#endif /* _SPEEX_CONFIG_TYPES_H */

