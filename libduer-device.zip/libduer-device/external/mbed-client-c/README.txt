The mbed Device C Client Library provides a simple and efficient way to create mbed Device Client in 
C.